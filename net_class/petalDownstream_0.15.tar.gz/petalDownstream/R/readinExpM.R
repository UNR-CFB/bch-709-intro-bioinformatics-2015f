
readinExpM <- function(FileInput){

	m1 = scan(FileInput, sep="\t", what="", nlines=1)
	m2 = scan(FileInput, sep="\t", what="", nlines=1, skip=1)

	if(isTRUE(length(m1)==length(m2))){
		expression     = matrix(scan(FileInput,what="",sep="\t", skip=1),ncol=length(m1), byrow=TRUE)
		expM           = matrix(as.numeric(expression[,-1]), ncol = length(m1)-1, byrow=FALSE)
		colnames(expM) = m1[-1]
		rownames(expM) = expression[,1]
	}else{
		expression     = matrix(scan(FileInput, sep="\t", what="", skip=1), ncol=length(m2), byrow=TRUE)
		expM           = matrix(as.numeric(expression[,-1]), ncol=length(m2)-1, byrow=FALSE)
		colnames(expM) = m1
		rownames(expM) = expression[,1]
	}
	rm(m1, m2,expression)

	# number of genes
	numGenes = dim(expM)[1]
	# saving number of genes  
	save(numGenes, file="numGenes.RData")

	return(expM)
}


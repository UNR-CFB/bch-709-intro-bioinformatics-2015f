

readinTable <- function(fileNameMM){
	m1 = scan(fileNameMM, sep="\t", what="", nlines=1)
	MM = matrix(scan(fileNameMM, sep="\t", what="", skip=1), ncol=length(m1), byrow=TRUE)
	colnames(MM) = m1
	return(MM)
}


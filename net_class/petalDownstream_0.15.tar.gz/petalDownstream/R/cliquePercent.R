
#############################################################################################################
#############################################################################################################

densityM <- function(FriendsM, FileOut=NULL, outReturn=TRUE){
	n = dim(FriendsM)[1]
	numEdges = (sum(rowSums(FriendsM))-n)/2		# number of edges in the matrix
	cliqueEdges = ((n-1)*n)/2			# number of edges in matching perfect clique
	
	if(length(FileOut)!=0){
	toFile = paste("This subnetwork has a density of: ", round(numEdges/cliqueEdges,digits=4), sep="")
   	writeToFile(toFile, FileOut, TRUE)
	rm(toFile)

	 if(isTRUE((cliqueEdges-numEdges)!=0)){
		if(isTRUE((cliqueEdges-numEdges)==1)){
		      toFile = paste("In the ", n, "-node subnetwork ", cliqueEdges-numEdges, " edge is missing to be a clique", sep="")
   	              writeToFile(toFile, FileOut, TRUE)
		}else{toFile = paste("In the ", n, "-node subnetwork ", cliqueEdges-numEdges, " edges are missing to be a clique", sep="")
   	              writeToFile(toFile, FileOut, TRUE)
		}
	 }
	}
	if(outReturn){return(numEdges/cliqueEdges)}
}


densityL <- function(Friends, AdjMatrix, FileOut=NULL, outReturn=TRUE){

        tmpIndex = match(Friends, rownames(AdjMatrix))
	FriendsM = AdjMatrix[tmpIndex,tmpIndex]

	n = dim(FriendsM)[1]
	numEdges = (sum(rowSums(FriendsM))-n)/2		# number of edges in the matrix
	cliqueEdges = ((n-1)*n)/2			# number of edges in matching perfect clique
	
	if(length(FileOut)!=0){
	toFile = paste("This subnetwork has a density of: ", round(numEdges/cliqueEdges,digits=4), sep="")
   	writeToFile(toFile, FileOut, TRUE)
	rm(toFile)

	 if(isTRUE((cliqueEdges-numEdges)!=0)){
		if(isTRUE((cliqueEdges-numEdges)==1)){
		      toFile = paste("In the ", n, "-node subnetwork ", cliqueEdges-numEdges, " edge is missing to be a clique", sep="")
   	              writeToFile(toFile, FileOut, TRUE)
		}else{toFile = paste("In the ", n, "-node subnetwork ", cliqueEdges-numEdges, " edges are missing to be a clique", sep="")
   	              writeToFile(toFile, FileOut, TRUE)
		}
	 }
	}
	if(outReturn){return(numEdges/cliqueEdges)}
}


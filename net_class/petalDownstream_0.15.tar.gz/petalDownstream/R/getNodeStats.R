
getNodeStats <-function(AdjM,totxtFile=FALSE){

	#converting adjacency matrix to a graph format for igraph to use it
	library("igraph")
	GraphAdjM = graph.adjacency(AdjM, mode="undirected", weighted=NULL, diag=TRUE, add.colnames=NULL)
	LocalCC = round(transitivity(GraphAdjM, type="local"), digit=3)
	rm(GraphAdjM)

	## node stats
	Index=seq(1:dim(AdjM)[1])
	k_net=rowSums(AdjM)-1

	nodeStatsT=cbind(Index,rownames(AdjM),LocalCC,k_net)
	colnames(nodeStatsT) = c("Index", "gene","LocalCC","k")

	if(totxtFile){write.table(nodeStatsT,file="NetworkNodeStats.txt",sep="\t", quote=FALSE, row.names=FALSE, col.names=TRUE)}

	save(nodeStatsT, file="NodeStats.RData")
	return(nodeStatsT)
}



findMaximalCliques <- function(adjMatrix){
   library("igraph")
   smallG = graph.adjacency(adjMatrix,mode="undirected", weighted=NULL, diag=TRUE, add.colnames=NULL)
   MC = maximal.cliques(smallG)
#  print(paste("There are ", length(MC), " maximal cliques", sep=""))
   return(MC)
}

findLargestCliques <- function(adjMatrix){
	library("igraph")
	smallG = graph.adjacency(adjMatrix,mode="undirected", weighted=NULL, diag=TRUE, add.colnames=NULL)
	LC = largest.cliques(smallG)

	LCM = NULL
	for(i in 1:length(LC)){
		x   = as.vector(LC[[i]])
		LCM = cbind(LCM, x)	
	}			
#	print(paste("There are ", dim(LCM)[2], " largest cliques of size ", dim(LCM)[1], sep=""))
	return(LCM)
}





# writes to function without row or column names

writeToFile <- function(information,fileName, appending){
	write.table(information,file=fileName, sep="\t", quote=FALSE, row.names=FALSE, col.names=FALSE, append=appending)
}


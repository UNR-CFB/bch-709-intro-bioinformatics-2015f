
##################################################################################################
##################################################################################################

plotExpProfiles <- function(currentSubgroup, expMatrix, fileName, title=NULL, farbe=NULL){
 	index = match(currentSubgroup, rownames(expMatrix))
	n = length(index)
	if(is.null(farbe)){cl = rainbow(n)
		}else{  cl = vector(mode="logical",length= n)
		        cl[1:n] = farbe
	}

	tiff(filename=paste(fileName,".tiff", sep=""), width=7, height=8.5, units="in", pointsize=12, compression="lzw", bg="white", res=600)
	plot.profiles(expMatrix[index,], colnames(expMatrix), title, cl)
 	dev.off()
 }

##################################################################################################

plot.profiles <- function(expressionM, measures, header, cl){
  plot.new()						# makes a canvas
  par(ps=12,mar=c(4,4,2,2),font=2)			# sets margins somehow, not sure i need
 
  v<-as.vector(expressionM)
  v<-v[!is.na(v)]
  MAX<-max(max(v))
  MIN<-min(min(v))
 
  X<-c(1:length(measures))

  plot(c(1,X[length(X)]),c(MIN-1,MAX),pch=16,cex=0, font.lab=1,cex.lab=1.2,cex.axis=1.2,main=header, xlab="",ylab="Expression",xaxt="n")
  if(length(expressionM) > length(measures)){
        for(i in 1:dim(expressionM)[1]){
              Y<-expressionM[i,]
              points(X,Y,pch=16,cex=.5,col=cl[i])
              lines(X,Y,lwd=1,col=cl[i])
         #     text(.2,Y[1],substr(rownames(expressionM)[i],10,nchar(rownames(expressionM)[i])),cex=.65)
        }
  }
}


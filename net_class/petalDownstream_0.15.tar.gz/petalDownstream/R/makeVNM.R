




makeVNM <- function(currentSubgroup, adjMatrix){

   nodeIndex = match(currentSubgroup, rownames(adjMatrix))
   tmpM      = adjMatrix[,nodeIndex]

   if(isTRUE(length(nodeIndex)==1)){
   	 Friends   = as.vector(which(tmpM==1))
   }else{Friends   = as.vector(which(rowSums(tmpM)==length(nodeIndex)))}

   FriendsM  = adjMatrix[Friends,Friends]
	
   if(length(Friends)==0){
	   print("The gene group entered is not a completely connected subgraph, try to analyze the genes separately or clique them first.")
   }else{  return(FriendsM)}

}

